package bsi.mpoo.traineeufrpe.gui.main;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewFlipper;

import bsi.mpoo.traineeufrpe.R;
import bsi.mpoo.traineeufrpe.gui.empregador.acesso.ActCadastroLoginEmpregador;
import bsi.mpoo.traineeufrpe.gui.estagiario.acesso.ActCadastroLoginEstagiario;

public class ActHome extends AppCompatActivity {
    private Button butest;
    private Button butemp;
    private TextView contact;
    private ViewFlipper viewFlipper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewFlipper = findViewById(R.id.viewflip);
        viewFlipper.setAutoStart(true);
        viewFlipper.setFlipInterval(1500);
        viewFlipper.startFlipping();

        butemp = findViewById(R.id.butEmpregador);
        butest = findViewById(R.id.butEstagiario);

        butest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent abreEst = new Intent(getBaseContext(), ActCadastroLoginEstagiario.class);
                startActivity(abreEst);
            }
        });

        butemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent abreTelaEmpregador = new Intent(getBaseContext(), ActCadastroLoginEmpregador.class);
                startActivity(abreTelaEmpregador);
            }
        });

        contact = findViewById(R.id.contato2);

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent abreTelaContato = new Intent(getBaseContext(), ActContato.class);
                startActivity(abreTelaContato);
            }
        });

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
